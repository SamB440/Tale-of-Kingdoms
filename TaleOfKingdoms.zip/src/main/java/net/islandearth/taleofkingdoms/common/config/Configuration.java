package net.islandearth.taleofkingdoms.common.config;

import net.islandearth.taleofkingdoms.TaleOfKingdoms;
import net.minecraftforge.common.config.Config;

public class Configuration {

	@Config(modid = TaleOfKingdoms.MODID)
	public static class TOKConfig {
		
	}
}
