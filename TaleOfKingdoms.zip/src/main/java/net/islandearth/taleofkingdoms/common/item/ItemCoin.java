package net.islandearth.taleofkingdoms.common.item;

import net.minecraft.item.Item;

public class ItemCoin extends Item {
	
	public ItemCoin(String name) {
		this.setRegistryName(name);
		this.setUnlocalizedName(name);
	}
}
