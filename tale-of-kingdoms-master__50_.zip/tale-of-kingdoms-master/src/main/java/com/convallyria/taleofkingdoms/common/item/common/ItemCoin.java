package com.convallyria.taleofkingdoms.common.item.common;

import net.minecraft.item.Item;

public class ItemCoin extends Item {

    public ItemCoin(Settings settings) {
        super(settings);
    }

}
