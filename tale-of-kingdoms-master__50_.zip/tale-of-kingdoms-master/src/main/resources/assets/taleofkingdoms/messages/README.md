# Messages
This is a directory containing all message json used in ToK via https://minecraftjson.com/.