# Textures
Textures belong to the copyright of their respective authors.

You may not use, modify, or redistribute them without prior permission.